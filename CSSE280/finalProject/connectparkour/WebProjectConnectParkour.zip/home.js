// onload.
$(function() {
	
	$("#home").addClass("active");

	$("#logout").click(logout);
	
	$.ajax("getEventInfoUser.php", {
		type:"GET",
		datatype:"json"
	}).done(fillEvents).fail(failed);

});

function showEvent() {

    console.log("showEvent");

    $(this).next().slideToggle();
}

function login(){
    console.log("login");
	window.location.href = "Login.php";
} 

function logout(){
	document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
	window.location.href = "Login.php";
}

function fillEvents(data){
	console.log("in fill events");
	parsedData = JSON.parse(data);
	var eventmenu = $("#eventMenu");
	for(var i = 0; i < parsedData.length; i++){
		var dt = $("<dt>");
		dt.append(parsedData[i].EventName + " " + parsedData[i].Date);
		var dd = $("<dd>");
		var divrow = $("<div class='row'>");
		var divcol = $("<div class='col-xs-3'>");
		var image = "<img src='" + parsedData[i].Path + "' alt='Pic' style='height:98px;width=100px;'/>";
		divcol.append(image);
		var divcol2 = $("<div class='col-xs-4'>");
		var p = $("<p>");
		p.append(parsedData[i].City + ", " + parsedData[i].State);
		divcol2.append(p);
		var divcol3 = $("<div clas='col-xs-4'>");
		p = $("<p>");
		var type = "";
		if(parsedData[i].Type = 0){
			type = "Outside";
		} else { 
			type = "Inside"; 
		}
		console.log("Event scheduled by: <a href='aboutme.php?username=" + parsedData[i].PostedBy + "'>"+ parsedData[i].PostedBy + "</a><br> Type: " + type);
		p.append("Event scheduled by: <a href='aboutme.php?username=" + parsedData[i].PostedBy + "'>"+ parsedData[i].PostedBy + "</a><br> Type: " + type);
		divcol3.append(p);
		divrow.append(divcol);
		divrow.append(divcol2);
		divrow.append(divcol3);
		dd.append(divrow);
		eventmenu.append(dt);
		eventmenu.append(dd);
	}
	$("#eventMenu dt").click(showEvent);
}

function failed(){
	alert("failed to load events");
}


